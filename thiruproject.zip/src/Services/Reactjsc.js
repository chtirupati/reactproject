import React from 'react';

const Reactjsc = () => {
    return (<>
        <div className="container py-2">
            <img src="https://hackernoon.com/hn-images/1*jhD-rWxuFvo17Q1Mw6LuEw.jpeg" alt="rs" className="w-100"/>
        </div>
   </> );
};

export default Reactjsc;