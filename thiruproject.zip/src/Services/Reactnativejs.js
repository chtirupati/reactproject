import React from 'react';

const Reactnativejs = () => {
    return (<>
         <div className="container py-2">
           <img src="https://www.maansoftwares.com/sites/default/files/inline-images/reactnative-infograph.jpg" alt="rt" className="w-100"/>
        </div>
   </> );
};

export default Reactnativejs;