import React from 'react';

const Vu = () => {
    return (<>
        <div className="container py-2">
             <img src="https://fiverr-res.cloudinary.com/images/q_auto,f_auto/gigs/104709483/original/e589bbe73cdfc001f524b3030d6ddf6a14c52802/fix-any-laravel-and-vujs-bugs-or-issues.png" alt="rt" className="w-100"/>
        </div>
    </>);
};

export default Vu;