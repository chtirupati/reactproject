import React from 'react';

const Angularjs = () => {
    return (<>
        <div className="container py-2">
            <img src="https://www.tristatetechnology.com/tristate-website/blog/wp-content/uploads/2017/09/Why-AngularJS-A1.jpg" alt="rt" className="w-100" />
        </div>
    </>);
};

export default Angularjs;