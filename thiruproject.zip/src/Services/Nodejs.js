import React from 'react';

const Nodejs = () => {
    return (<>
        <div className="container py-2">
             <img src="https://www.simform.com/wp-content/uploads/2019/11/Node.JS-Use-Cases-Cover-Image.png" alt="rt" className="w-100"/>
        </div>
    </>);
};

export default Nodejs;