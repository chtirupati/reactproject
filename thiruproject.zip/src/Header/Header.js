import React from 'react';

import { NavLink, Link } from 'react-router-dom'

const Header = () => {
    return (<>

        <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="container">
                <NavLink className="navbar-brand" to="/home">
                    <img src="./../images/react.png" className="reactlogo" alt="vijaysirimage" style={{ height: '60px' }} />
                </NavLink>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" >
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul className="navbar-nav ">
                        <li className="nav-item active">
                            <NavLink className="nav-link" activeClassName="text-white bg-dark" to="/home">Home <span className="sr-only">(current)</span></NavLink>
                            
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link" activeClassName="text-white bg-dark" to="/about">About</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link" activeClassName="text-white bg-dark" to="/services">Services</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link " activeStyle={{ backgroundColor: '#eee', color: 'purple' }} to="/contact" >Contact</NavLink>
                        </li>
                        <li className="nav-item dropdown">
                            <Link className="nav-link dropdown-toggle" to="/training" id="navbarDropdown"  data-toggle="dropdown" >
                                Training
                            </Link>
                            
                            <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                <Link className="dropdown-item" to="/training/reactjsc">React</Link>
                                <Link className="dropdown-item" to="/training/reactnativejs">ReactNative</Link>
                             
                                <Link className="dropdown-item" to="/training/nodejs">Nodejs</Link>
                            </div>
                        </li>


                        {/* <li className=" nav-link nav-item  dropdown">
                            <Link  to="/about">Training</Link>
                            <span className=" dropdown-toggle" data-toggle="dropdown"></span>
                            <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                <Link className="dropdown-item" to="/training/reactjsc">React</Link>
                                <Link className="dropdown-item" to="/training/reactnativejs">ReactNative</Link>
                             
                                <Link className="dropdown-item" to="/training/nodejs">Nodejs</Link>
                            </div>
                        </li> */}



                    </ul>
                </div>
            </div>
        </nav>
    </>);
};

export default Header;