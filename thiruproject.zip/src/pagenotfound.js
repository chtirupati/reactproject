import React from 'react';

const pagenotfound = () => {
    return (<>
        <div className="container">
            <div className="row">
            <div className="col-md-12">
                
                    <h1 className="jumbotron">401</h1>
                    <h1>Page cannot found</h1>
               

            </div>
            </div>
            
        </div>
    </>);
};

export default pagenotfound;