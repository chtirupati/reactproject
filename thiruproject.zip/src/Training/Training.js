import React from 'react';


const Training = () => {
    return (<>
       
   </> );
};

export default Training;