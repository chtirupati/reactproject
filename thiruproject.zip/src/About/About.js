import React from 'react';
import { Link } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHandPointRight } from '@fortawesome/free-solid-svg-icons'


const About = () => {
    return (<>
        <div class="container my-3">
            <h3>React Installtion Process</h3>
            <div className="process">
                <ol className="list-group">
                    <li className="list-group-item">
                        NodeJs Installtion<br />
                       
                        <Link to={{ pathname:"https://nodejs.org/en/" }} target="_blank" ><FontAwesomeIcon icon={faHandPointRight} color="#61DBFB" size="1x"  style={{color:'#61DBFB'}}/> https://nodejs.org/en/</Link>
                    </li>
                    <li className="list-group-item">
                        <p>Reactjs Installtion</p>
                        <p>npm i -g create-react-app</p>
                        
                    </li>
                    <li className="list-group-item">
                       <p> Create React App </p>
                        <p>create-react-app foldername</p>  
                        <p>Open Folder</p>
                        <p>npm start</p>
                        <p>http://localhost:3000</p>
                        <hr/>
                        <p>npm view react version <br/>

                            npm view react-native version <br/>

                            npm i react-native <br/>

                            npm i react-redux</p>
                    </li>
                    <li className="list-group-item">
                         <p>Create Package.Json </p>
                         npm init

                         <div className="d-flex ">
                             <div className="flex-fill ">
                             <img src="./../images/npmpackage1.png" alt="npmpackageimage" class="w-100"/>
                             </div>
                             <div className="flex-fill ">
                                 <img src="./../images/npmpackage.png" alt="npmpackageimage" class="w-100"/>
                             </div>
                             
                         </div>
                         
                     </li>
                     <li className="list-group-item">
                         <h3>Extra dependencies install (CLI)</h3>
                         npm i bootstrap <br/>
                        npm i jquery <br/>
                        npm install popper.js --save <br/>
                        npm install react-router-dom <br/>
                     </li>
                     <li className="list-group-item">
                         <h3>ReactDOM</h3>
                         import ReactDOM from 'react-dom'
                         ReactDOM.render("HELLO REACT",document.getElementById('root') );

                         <hr/>
                        
                     </li>

                     <li className="list-group-item">
                     <h3>React JSX</h3>
                     <p>import react from 'react';</p>
                    <p>JAVASCRIPT+HTML=JSX</p>

                    <p>JSX[JAVASCRIPT+TAGSL-VIEW OF RESULT</p>

                    <p>JS+HTML=JSX</p>
                     </li>

                     <li className="list-group-item">
                            <p>Inbuilt installtion</p>
                         react  Package  - Support / use React Functanalities into Your project <br/>

                         react-dom  Package  -  Support / Use DOM Functionalities into your project <br/>

                         react-scripts Package -  Compile and Run your project files...<br/>
                     </li>
                     <li className="list-group-item">
                         <h3>Types of Components</h3>


                        - Functional Component [javascript Function]<br/>

                        - Class Component [Ecmascript OOPS]<br/>

                        - React Hooks Component [NEW Feature]<br/>

                        - Higher Order Component [NEW Feature]<br/>
                     </li>

                     <li className="list-group-item">
                        <h3>Important class C6.MAP AND LIST</h3>
                     </li>

                </ol>
            </div>
        </div>
    </>);
};

export default About;