import React from 'react';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom'
import Home from './Home/Home.js'
import About from './About/About.js'
import Services from './Services/Services.js'
import Contact from './Contact/Contact.js'
import Header from './Header/Header.js'
import Footer from './Footer/Footer.js'
import Training from './Training/Training.js'

import pagenotfound from './pagenotfound.js';

import Reactjsc from './Services/Reactjsc.js'
import Reactnativejs from './Services/Reactnativejs.js'
import Nodejs from './Services/Nodejs.js'



const Routings = () => {
    return (<>
        <BrowserRouter>
            <Header />
            <Switch>
                <Route exact path="/" component={Home} />
                <Route  path="/home" component={Home} />
                <Route  path="/about" component={About} />
                <Route  path="/services" component={Services} />
                <Route  path="/contact" component={Contact} />
               
               
                <Route exact path="/training" component={Training} />
                <Route path="/training/reactjsc" component={Reactjsc}/>
                <Route path="/training/reactnativejs" component={Reactnativejs}/>
                <Route path="/training/nodejs" component={Nodejs}/>
                <Redirect to="/home" />
                <Route component={pagenotfound} />
               

            </Switch>
            <Footer />
        </BrowserRouter>
    </>);
};

export default Routings;